from PySide6.QtCore import QTimer, QPoint, QEvent
from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QGraphicsDropShadowEffect
from PySide6.QtGui import QMouseEvent, QColor, Qt

class UIFunctions:
    def uiDefinitions(self):
        # 双击标题栏最大化/还原功能
        def dobleClickMaximizeRestore(event):
            if event.type() == QEvent.MouseButtonDblClick:
                QTimer.singleShot(250, lambda: self.maximize_restore())
        self.ui.frame_2.mouseDoubleClickEvent = dobleClickMaximizeRestore

        # 设置窗口为无边框且透明背景（用于自定义标题栏效果）
        self.setWindowFlags(Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground)

        # 实现窗口拖动功能
        def moveWindow(event):
            if self.isMaximized():
                self.maximize_restore()
            if event.buttons() == Qt.LeftButton:
                global_position = QPoint(int(event.globalPosition().x()), int(event.globalPosition().y()))
                pos_point = QPoint(self.pos())
                dragPos_point = QPoint(int(self.dragPos.x()), int(self.dragPos.y()))
                self.move(pos_point + global_position - dragPos_point)
                self.dragPos = QPoint(global_position)
                event.accept()

        self.ui.frame_2.mouseMoveEvent = moveWindow


        # 自定义最小化按钮点击事件
        self.ui.min.clicked.connect(self.showMinimized)

        # 自定义最大化/还原按钮点击事件
        self.ui.max.clicked.connect(self.maximize_restore)

        # 自定义关闭按钮点击事件
        self.ui.close.clicked.connect(self.close)

        # 投影效果设置
        self.shadow = QGraphicsDropShadowEffect(self)
        self.shadow.setBlurRadius(17)
        self.shadow.setXOffset(0)
        self.shadow.setYOffset(0)
        self.shadow.setColor(QColor(0, 0, 0, 150))
        self.ui.widget.setGraphicsEffect(self.shadow)

        # bind buttonstyles
        self.Button_styles()


    def maximize_restore(self):
        if self.isMaximized():
            self.showNormal()
        else:
            self.showMaximized()

    def Button_styles(self):
        self.ui.pushButton.setParams(
            text="导入图片分析",
            border_radius=5,
            full_color=QColor('#34495e'),
            font_anim_start_color=QColor('#34495e'),
            font_anim_finish_color=QColor("#ffffff"),
        )
        self.ui.pushButton_2.setParams(
            text="统计",
            border_radius=5,
            full_color=QColor('#34495e'),
            font_anim_start_color=QColor('#34495e'),
            font_anim_finish_color=QColor("#ffffff"),
        )
        self.ui.pushButton_3.setParams(
            text="结果分析",
            border_radius=5,
            full_color=QColor('#34495e'),   #放上去的时候的颜色
            font_anim_start_color=QColor('#34495e'),
            font_anim_finish_color=QColor("#ffffff"),
        )
        self.ui.function1.setParams(
            text="摄像头:关",
            border_radius=5,
            full_color=QColor('#34495e'),
            font_anim_start_color=QColor('#34495e'),
            font_anim_finish_color=QColor("#ffffff"),
        )
        self.ui.function2.setParams(
            text="识别与计数：关",
            border_radius=5,
            full_color=QColor('#34495e'),
            font_anim_start_color=QColor('#34495e'),
            font_anim_finish_color=QColor("#ffffff"),
        )
        self.ui.function3.setParams(
            text="导出数据",
            border_radius=5,
            full_color=QColor('#34495e'),
            font_anim_start_color=QColor('#34495e'),
            font_anim_finish_color=QColor("#ffffff"),
        )
