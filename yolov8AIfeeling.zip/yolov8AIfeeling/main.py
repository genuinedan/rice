from ui_main import Ui_MainWindow
import sys
from PySide6.QtCore import QTimer, QThread, Signal
from PySide6.QtGui import QImage, QPixmap, QIcon, Qt
from PySide6.QtWidgets import QApplication, QMainWindow, QMessageBox, QFileDialog
import cv2
from ultralytics import YOLO
from ui_function import UIFunctions
import matplotlib.pyplot as plt
from shutil import copy

# 设置字体为 SimHei（黑体），以支持中文
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题
# Gpu加速
cv2.setUseOptimized(True)
cv2.setNumThreads(0)
cv2.ocl.setUseOpenCL(True)


class open_camera_thread(QThread):
    frame_signer = Signal(object)
    anlyze_result_signal = Signal(bool)
    updata_uitext_signal = Signal(str, str)

    def __init__(self, cap, model, anlyze_signer, camera_signer):
        super().__init__()
        self.cap = cap
        self.model = model
        self.anlyze_signer = anlyze_signer
        self.camera_signer = camera_signer

    def run(self):
        print("当前标记开关状况:", self.camera_signer)
        if self.cap.isOpened():
            ret, frame = self.cap.read()
            if ret:
                if self.camera_signer:
                    # 调整图像尺寸，这里将图像缩小为原来的一半
                    resized_frame = cv2.resize(frame, (frame.shape[1] // 2, frame.shape[0] // 2))
                    results = self.model.predict(resized_frame)
                    count_dict = {}
                    temp_location_txt = ""
                    print("当前统计按钮是否按下：", self.anlyze_signer)
                    for r in results:
                        boxes = r.boxes
                        for box in boxes:
                            # 获取边界框坐标
                            x1, y1, x2, y2 = box.xyxy[0]
                            x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
                            # 获取类别标签和置信度
                            class_label = self.model.names[int(box.cls[0])]
                            confidence = box.conf[0]
                            # 在画面上绘制边界框和标签，将坐标映射回原始图像大小
                            cv2.rectangle(frame, (x1 * 2, y1 * 2), (x2 * 2, y2 * 2), (0, 255, 0), 2)
                            label_text = f"{class_label}: {confidence:.2f}"
                            cv2.putText(frame, label_text, (x1 * 2, y1 * 2 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                                        (0, 255, 0),
                                        2)
                            if self.anlyze_signer:
                                temp_location_txt += class_label + f": ({x1 * 2},{y2 * 2}),({x2 * 2},{y2 * 2})\n"
                                if class_label in count_dict:
                                    count_dict[class_label] += 1
                                else:
                                    count_dict[class_label] = 1

                    if self.anlyze_signer:
                        # 更新数据结果
                        temp_txt = ""
                        for key, value in count_dict.items():
                            temp_txt += key + " :  " + str(value) + "\n"

                        print(temp_txt)
                        self.updata_uitext_signal.emit(temp_txt, temp_location_txt)
                        self.anlyze_signer = False
                        self.anlyze_result_signal.emit(self.anlyze_signer)
                self.frame_signer.emit(frame)


class loader(QThread):
    model_loaded_signal = Signal(object)  # 定义信号，用于发送加载好的模型对象

    def __init__(self):
        super().__init__()

    def run(self):
        try:
            model = YOLO(r'yolov8n.pt')  # 加载 YOLO 模型
            self.model_loaded_signal.emit(model)  # 加载成功后，发送模型对象信号
        except Exception as e:
            print(f"模型加载出现错误: {e}")


class myapp(QMainWindow, UIFunctions):

    def __init__(self):
        super().__init__()
        # 创建 Ui_MainWindow 类的实例
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        # function 区
        self.ui.function1.clicked.connect(self.functiongroup)
        self.ui.function2.clicked.connect(self.functiongroup)
        self.ui.function3.clicked.connect(self.functiongroup)
        self.ui.pushButton.clicked.connect(self.functiongroup)
        self.ui.pushButton_2.clicked.connect(self.functiongroup)
        self.ui.pushButton_3.clicked.connect(self.functiongroup)

        # 次数
        self.ci = 0
        # 用于存储摄像头对象
        self.cap = None
        # 定时器，用于定时更新摄像头画面
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.start_new_camera_thread)
        # 用于显示摄像头画面的 QLabel
        self.label_camera = self.ui.label_camera
        # 摄像头标签开启标
        self.camera_signer = False
        # 识别标志
        self.anlyze_signer = False
        # 调用 UIFunctions 类中的 uiDefinitions 方法进行 UI 相关设置
        self.uiDefinitions()
        # 加载模型子线程
        self.model_thread = loader()
        self.model_thread.model_loaded_signal.connect(self.model_thread_result)
        self.model_thread.start()

        # 存储当前处理的线程
        # self.current_camera_thread = None
        self.camera_open_thread = None

    def model_thread_result(self, model):
        self.model = model
        print("成功加载模型")

    def open_camera(self):
        self.cap = cv2.VideoCapture(0)
        if not self.timer.isActive():
            if self.anlyze_signer:
                self.timer.start(2000)
            else:
                self.timer.start(50)

    def start_new_camera_thread(self):
        if self.camera_open_thread is not None and self.camera_open_thread.isRunning():
            self.camera_open_thread.wait()
        self.camera_open_thread = open_camera_thread(self.cap, self.model, self.anlyze_signer, self.camera_signer)
        self.camera_open_thread.frame_signer.connect(self.update_frame)
        self.camera_open_thread.updata_uitext_signal.connect(self.update_uitext)
        self.camera_open_thread.anlyze_result_signal.connect(self.update_anlyze_signer)
        self.camera_open_thread.start()

    def close_camera(self):
        self.timer.stop()
        if self.camera_open_thread is not None or self.camera_open_thread.isRunning():
            self.camera_open_thread.wait()
            self.camera_open_thread = None
        self.ui.label_camera.setPixmap(QPixmap())

    def update_frame(self, frame):
        self.display_pixmap(frame)

    def update_anlyze_signer(self, result):
        self.anlyze_signer = result

    def update_frame_with_processed_frame(self, processed_frame):
        # 将处理后的帧显示在 QLabel 上
        self.display_pixmap(processed_frame)
        self.current_camera_addlabel_thread.wait()
        self.current_camera_addlabel_thread = None

    def update_uitext(self, temp_txt, temp_location_txt):

        self.ui.output2.setPlainText(temp_txt)
        self.ui.output1.setPlainText(temp_location_txt)

    def display_pixmap(self, frame):
        # 获取 label_camera 的尺寸
        label_size = self.label_camera.size()
        # 将 OpenCV 的 BGR 格式图像转换为 RGB 格式（Qt 中使用 RGB 格式）
        cv2.imwrite('./temp/output_temp.jpg', frame)
        image = QImage('./temp/output_temp.jpg')
        pixmap = QPixmap(image)
        # 创建 QPixmap 对象
        # pixmap = QPixmap.fromImage(image)

        scaled_pixmap = pixmap.scaled(
            label_size,
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation
        )
        self.label_camera.setPixmap(scaled_pixmap)

    def functiongroup(self):
        # 获取点击的按钮
        btn = self.sender()
        btnName = btn.objectName()
        # 摄像头功能
        if btnName == "function1":
            if self.ui.function1.text() == "摄像头:开":
                self.ui.function1.setText("摄像头:关")
                self.close_camera()

            else:
                self.ui.function1.setText("摄像头:开")
                self.open_camera()
        # 标记开
        if btnName == "function2":
            if self.ui.function2.text() == "识别与计数：关":
                self.ui.function2.setText("识别与计数：开")
                # 摄像头标记开
                self.camera_signer = True

                # 如果只点了识别与计数功能， 顺带将摄像头和识别功能都打开
                if self.ui.function1.text() == "摄像头:关":
                    self.ui.function1.setText("摄像头:开")
                    self.open_camera()
                # 识别函数

            else:
                self.ui.function2.setText("识别与计数：关")
                self.camera_signer = False
        # 导出数据-文本信息，图片标注，图表
        if btnName == "function3":
            if self.ui.output2.toPlainText() != "":
                if self.ui.function1.text() == "摄像头:开":
                    self.close_camera()
                try:
                    # 弹出文件选择对话框
                    file_dialog = QFileDialog()
                    save_dir = file_dialog.getExistingDirectory(
                        self,  # 父窗口
                        "选择保存目录",  # 对话框标题
                        "",  # 初始目录，这里使用当前目录
                    )
                    if save_dir:
                        # 假设将数据保存为 data.txt
                        temp_txt = self.ui.output2.toPlainText()
                        txt_path = f"{save_dir}/data_{self.ci}.txt"
                        with open(txt_path, "w") as f:
                            f.write(temp_txt)
                        print(f"数据已保存到 {txt_path}")

                        if self.ui.output3.pixmap():
                            img_path = f"{save_dir}/data_img_{self.ci}.jpg"
                            copy("./temp/temp.jpg", img_path)
                            print(f"图像已保存到 {img_path}")
                        img_label_path = f"{save_dir}/data_img_addlabel_{self.ci}.jpg"
                        copy("./temp/output_temp.jpg", img_label_path)
                    self.show_info("成功导出数据")
                    print("成功导出数据")
                    self.ci += 1
                    if self.ui.function1.text() == "摄像头:开":
                        self.open_camera()
                except:
                    self.show_warning("导出失败")
                    print("导出失败")
            else:
                self.show_warning("目前没有进行统计")

        # 导入图片分析
        if btnName == "pushButton":
            # 打开文件选择对话框，获取选择的文件路径
            if self.ui.function1.text() == "摄像头:关":
                file_dialog = QFileDialog()
                file_path, _ = file_dialog.getOpenFileName(
                    self,  # 父窗口
                    "选择文件",  # 对话框标题
                    "",  # 初始目录，这里使用当前目录
                    "图片文件 (*.jpg *.png *.jpeg *.bmp *.gif)"
                )
                if file_path:
                    print(f"选择的文件路径: {file_path}")
                    count_dict = {}
                    temp_location_txt = ""
                    frame = cv2.imread(file_path, cv2.IMREAD_COLOR)
                    results = self.model.predict(frame)
                    for r in results:
                        boxes = r.boxes
                        for box in boxes:
                            # 获取边界框坐标
                            x1, y1, x2, y2 = box.xyxy[0]
                            x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
                            # 获取类别标签和置信度
                            class_label = self.model.names[int(box.cls[0])]
                            confidence = box.conf[0]
                            # 在画面上绘制边界框和标签
                            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                            label_text = f"{class_label}: {confidence:.2f}"
                            cv2.putText(frame, label_text, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0),
                                        2)
                            temp_location_txt += class_label + f": ({x1},{y2}),({x2},{y2})\n"
                            if class_label in count_dict:
                                count_dict[class_label] += 1
                            else:
                                count_dict[class_label] = 1
                    self.display_pixmap(frame)

                    # 更新数据结果
                    temp_txt = ""
                    for key, value in count_dict.items():
                        temp_txt += key + " :  " + str(value) + "\n"

                    self.ui.output2.setPlainText(temp_txt)
                    self.ui.output1.setPlainText(temp_location_txt)

            else:
                self.show_warning("目前正在实时识别中！！！\n不可以导入图片分析！！！")

        # 统计-摄像头
        if btnName == "pushButton_2":
            if self.ui.function2.text() == "识别与计数：关" and self.ui.function1.text() == "摄像头:关":
                self.show_warning("当前不处在实时识别中\n无法识别")
            else:
                if self.ui.function1.text() == "摄像头:关":
                    self.open_camera()
                    self.ui.function1.setText("摄像头:开")
                if self.ui.function2.text() == "识别与计数：关":
                    self.ui.function2.setText("识别与计数：开")
                    # 摄像头标记开
                    self.camera_signer = True
                self.anlyze_signer = True

        # 结果分析-画柱状图
        if btnName == "pushButton_3":
            temp_text = self.ui.output2.toPlainText().strip()
            if temp_text != "":
                categories = []
                values = []
                for line in temp_text.split("\n"):
                    print(line.split(" :  "))
                    item, count = line.split(" :  ")
                    item = item.strip()
                    count = count.strip()
                    categories.append(item)
                    values.append(int(count))
                print(values)
                self.drawing_bar(categories, values)

                # 获取 label_camera 的尺寸
                label_size = self.ui.output3.size()
                # 创建 QImage 对象
                image = QImage("./temp/temp.jpg")
                # 创建 QPixmap 对象
                pixmap = QPixmap.fromImage(image)
                scaled_pixmap = pixmap.scaled(
                    label_size,
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation
                )
                self.ui.output3.setPixmap(scaled_pixmap)

        print(f"鼠标点击:{btnName}")

    # 创建柱状图
    def drawing_bar(self, categories, values):
        plt.figure(figsize=(10, 6))  # 设置图形的大小
        plt.bar(categories, values, color='skyblue')  # 绘制柱状图，颜色为天蓝色
        # 添加标题和标签
        plt.title('识别结果统计')  # 图形的标题
        plt.xlabel('类别')  # x 轴的标签
        plt.ylabel('数值')  # y 轴的标签
        # 添加数据标签
        for i, v in enumerate(values):
            plt.text(i, v + 1, str(v), ha='center')  # 在每个柱子上方添加数据标签，将 v 转换为整数再相加
        plt.savefig("./temp/temp.jpg")

    def show_warning(self, words):
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Icon.Warning)
        msg.setWindowIcon(QIcon("image/警告.ico"))
        msg.setText(words)
        msg.setWindowTitle("警告")
        msg.setStandardButtons(QMessageBox.Ok)
        msg.exec()

    def show_info(self, words):
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Icon.Information)
        msg.setWindowIcon(QIcon("image/成功.ico"))
        msg.setText(words)
        msg.setWindowTitle("警告")
        msg.setStandardButtons(QMessageBox.Ok)
        msg.exec()

    def mousePressEvent(self, event):
        # 设置窗口拖动位置
        self.dragPos = event.globalPosition()

        # 打印鼠标事件
        if event.buttons() == Qt.LeftButton:
            print('鼠标点击：左键点击')
        if event.buttons() == Qt.RightButton:
            print('鼠标点击：右键点击')


if __name__ == "__main__":
    # 创建 QApplication 实例
    app = QApplication(sys.argv)
    # 创建主窗口实例
    main_window = myapp()
    # 显示主窗口
    main_window.show()
    # 进入应用程序的主循环
    sys.exit(app.exec())
